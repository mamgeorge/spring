package com.example.dgsDemo;

public class Show {
	//
	private String id;
	private String title;
	private Integer year;
	private String description;

	public Show(String id, String title, Integer year, String description) {
		this.id			= id;
		this.title		= title;
		this.year		= year;
		this.description= description;
	}

	public String getId() { return id; }

	public String getTitle() { return title; }

	public Integer getYear() { return year; }

	public String getDescription() { return description; }
	public void setDescription(String description) { this.description = description; }
}