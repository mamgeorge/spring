package com.example.dgsDemo;

import java.util.List;
import java.util.stream.Collectors;

import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsData;
import com.netflix.graphql.dgs.InputArgument;

@DgsComponent
public class ShowsDatafetcher {

    private final List<Show> shows = List.of(
		new Show( "10", "Stranger Things"			, 2016	, "SciFi" ),
		new Show( "11", "Ozark"						, 2017	, "Crime" ),
		new Show( "12", "The Crown"					, 2016	, "History" ),
		new Show( "13", "Dead to Me"				, 2019	, "Comedy" ),
		new Show( "14", "Orange is the New Black"	, 2013	, "Drama" )
    );

	// query viewInfo { shows(titleFilter: "") { id title year description } }
	@DgsData(parentType = "Query", field = "getShow")
	public List<Show> getShow( @InputArgument("titleFilter") String titleFilter ) {
		//
		if(titleFilter == null) { return shows; }
		List<Show> list = shows.stream().filter(s -> 
			s.getTitle().contains(titleFilter)).collect(Collectors.toList());
		return list;
	}
	
	// mutation changeDesc($input: DescriptionInput) { modDescription(input: $input) { id description } }
	// { "input": { "id": "13", "description": "Demo for Chase" } }
	@DgsData(parentType = "Mutation", field = "modDescription")
    public Show modDescription( @InputArgument("input") DescriptionInput DI ) {
		//
		// showService.saveShow(show);
		// List<Show> shows = showService.getShows(show.getShowId());
		// return Objects.requireNonNullElseGet(shows, List::of);
		Show shower = null;
		for(Show show: shows){
			if ( show.getId().equals( DI.getId() ) ) { 
				show.setDescription( DI.getDescription() ); 
				shower = show;
			}
		}
		return shower;
    }
}

class DescriptionInput {
	
	private String id;
	private String description;
	
	public String getId() { return id; }
	public void setId(String id) { this.id = id; }

	public String getDescription() { return description; }
	public void setDescription(String description) { this.description = description; }
}
	