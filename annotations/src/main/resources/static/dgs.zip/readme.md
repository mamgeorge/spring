c:\workspace\training\dgs\dgsDemo\readme.md

https://netflix.github.io/dgs/

	> cd c:\workspace\training\dgs\dgsDemo

for gradle

	> gradle			// installs local env

	> gradle tasks
	> gradle clean build --info -x test
	> gradle clean test --i | findstr /i INFO:
	> gradle bootrun

http://localhost:8080/graphiql
